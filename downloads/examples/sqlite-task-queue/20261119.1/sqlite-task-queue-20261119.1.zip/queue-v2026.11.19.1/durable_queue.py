import hashlib
import json
import sqlite3
import uuid
from contextlib import contextmanager


def canonical(payload):
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def connect(path):
    db = sqlite3.connect(path, isolation_level=None, timeout=5)
    db.row_factory = sqlite3.Row
    return db


@contextmanager
def transaction(db):
    db.execute("BEGIN IMMEDIATE")
    try:
        yield
        db.execute("COMMIT")
    except BaseException:
        if db.in_transaction:
            db.execute("ROLLBACK")
        raise


class Queue:
    def __init__(self, path, max_attempts=3):
        if not isinstance(max_attempts, int) or max_attempts < 1:
            raise ValueError("max_attempts must be positive")
        self.db = connect(path)
        self.max_attempts = max_attempts
        self.db.execute("""CREATE TABLE IF NOT EXISTS jobs(
            id TEXT PRIMARY KEY, payload TEXT NOT NULL,
            state TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
            available REAL NOT NULL, lease_until REAL,
            token TEXT, result TEXT, error TEXT)""")

    def submit(self, key, payload, now):
        if not key or len(key) > 200:
            raise ValueError("invalid idempotency key")
        data = canonical(payload)
        with transaction(self.db):
            old = self.db.execute("SELECT payload FROM jobs WHERE id=?", (key,)).fetchone()
            if old is not None:
                if old["payload"] != data:
                    raise ValueError("same key with different payload")
                return key
            self.db.execute("INSERT INTO jobs(id,payload,state,available) VALUES(?,?,'pending',?)",
                            (key, data, now))
        return key

    def claim(self, now, lease_seconds=30):
        if lease_seconds <= 0:
            raise ValueError("lease must be positive")
        with transaction(self.db):
            # Exhausted and abandoned work must not stay running forever.
            self.db.execute("""UPDATE jobs SET state='failed',token=NULL,error='lease exhausted'
                WHERE state='running' AND lease_until<=? AND attempts>=?""",
                (now, self.max_attempts))
            row = self.db.execute("""SELECT * FROM jobs WHERE attempts<? AND
                ((state='pending' AND available<=?) OR
                 (state='running' AND lease_until<=?))
                ORDER BY available,id LIMIT 1""", (self.max_attempts, now, now)).fetchone()
            if row is None:
                return None
            token = uuid.uuid4().hex
            self.db.execute("""UPDATE jobs SET state='running',attempts=attempts+1,
                lease_until=?,token=? WHERE id=?""", (now + lease_seconds, token, row["id"]))
            return dict(self.db.execute("SELECT * FROM jobs WHERE id=?", (row["id"],)).fetchone())

    def finish(self, job, now, result):
        r = self.db.execute("""UPDATE jobs SET state='done',result=?,token=NULL,error=NULL
            WHERE id=? AND state='running' AND token=? AND lease_until>?""",
            (canonical(result), job["id"], job["token"], now))
        return r.rowcount == 1

    def fail(self, job, now, retryable=True):
        # An application must classify errors; never retry all exceptions blindly.
        retry = retryable and job["attempts"] < self.max_attempts
        delay = min(60, 2 ** job["attempts"])
        r = self.db.execute("""UPDATE jobs SET state=?,available=?,token=NULL,error=?
            WHERE id=? AND state='running' AND token=? AND lease_until>?""",
            ("pending" if retry else "failed", now + delay,
             "retryable" if retryable else "permanent", job["id"], job["token"], now))
        return r.rowcount == 1

    def get(self, key):
        row = self.db.execute("SELECT * FROM jobs WHERE id=?", (key,)).fetchone()
        return dict(row) if row else None

    def close(self):
        self.db.close()


class FakeProvider:
    """Separate storage models an external provider accepting an idempotency key.
    This is not a real network call or a video model.
    """
    def __init__(self, path):
        self.db = connect(path)
        self.db.execute("""CREATE TABLE IF NOT EXISTS effects(
            key TEXT PRIMARY KEY, payload_hash TEXT NOT NULL, result TEXT NOT NULL)""")

    def create(self, key, payload):
        digest = hashlib.sha256(canonical(payload).encode()).hexdigest()
        with transaction(self.db):
            row = self.db.execute("SELECT * FROM effects WHERE key=?", (key,)).fetchone()
            if row:
                if row["payload_hash"] != digest:
                    raise ValueError("provider key conflict")
                return json.loads(row["result"])
            result = {"provider_task_id": uuid.uuid4().hex, "status": "accepted"}
            self.db.execute("INSERT INTO effects VALUES(?,?,?)", (key, digest, canonical(result)))
            return result

    def count(self):
        return self.db.execute("SELECT count(*) FROM effects").fetchone()[0]

    def close(self):
        self.db.close()
