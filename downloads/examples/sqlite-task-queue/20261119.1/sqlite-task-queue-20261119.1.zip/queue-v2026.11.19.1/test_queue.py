import json
import tempfile
from pathlib import Path
from durable_queue import Queue, FakeProvider

root = Path(tempfile.mkdtemp(prefix="video-queue-test-"))
q = Queue(root / "queue.sqlite")
other = Queue(root / "queue.sqlite")
p = FakeProvider(root / "provider.sqlite")
checks = []

def check(name, ok):
    assert ok, name
    checks.append(name)

payload = {"prompt": "synthetic example", "seconds": 4}
q.submit("tenant-a:job-1", payload, 0)
q.submit("tenant-a:job-1", payload, 0)
check("duplicate submit creates one row", q.db.execute("SELECT count(*) FROM jobs").fetchone()[0] == 1)
try:
    q.submit("tenant-a:job-1", {"seconds": 5}, 0)
    raise AssertionError("must reject key conflict")
except ValueError:
    checks.append("same key different payload rejected")
a = q.claim(0, 10)
check("second connection cannot claim live lease", other.claim(1, 10) is None)
result1 = p.create(a["id"], payload)
# Simulate crash AFTER provider accepted, BEFORE local acknowledgement.
q.close()
q = Queue(root / "queue.sqlite")
b = q.claim(11, 10)
check("restart recovers expired lease", b["attempts"] == 2 and b["token"] != a["token"])
result2 = p.create(b["id"], payload)
check("provider idempotency avoids second effect", p.count() == 1 and result1 == result2)
check("stale worker ack rejected", not q.finish(a, 12, result1))
check("new worker ack accepted", q.finish(b, 12, result2))
check("done job not reclaimed", q.claim(99, 10) is None)
q.submit("tenant-a:retry", payload, 100)
j = q.claim(100)
check("transient failure scheduled", q.fail(j, 101))
check("backoff not due", q.claim(102) is None)
j = q.claim(103)
check("backoff due", j["attempts"] == 2)
check("retry second failure", q.fail(j, 104))
j = q.claim(108)
check("third attempt exists", j["attempts"] == 3)
q.fail(j, 109)
check("retry bounded by attempts", q.get(j["id"])["state"] == "failed")
q.submit("tenant-a:bad-request", payload, 200)
j = q.claim(200)
q.fail(j, 201, retryable=False)
check("permanent error not retried", q.get(j["id"])["state"] == "failed")
q.submit("tenant-a:crash-limit", payload, 300)
for t in (300, 311, 322):
    check("expired lease claim " + str(t), q.claim(t, 10) is not None)
check("exhausted crash does not stay running", q.claim(333, 10) is None and q.get("tenant-a:crash-limit")["state"] == "failed")
q.close(); other.close(); p.close()
print(json.dumps({"sandbox": str(root), "checks": checks, "count": len(checks),
                  "limits": "local sequential multi-connection fault simulation; no real API, no process kill, no load test"}, ensure_ascii=False, indent=2))
