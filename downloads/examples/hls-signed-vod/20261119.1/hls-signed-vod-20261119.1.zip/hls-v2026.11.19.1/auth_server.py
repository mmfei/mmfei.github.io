import argparse
import hashlib
import hmac
import os
import re
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlsplit


def signature(secret, path, expiry):
    message = f"{path}\n{expiry}".encode()
    return hmac.new(secret, message, hashlib.sha256).hexdigest()


def signed_url(secret, path, expiry):
    return path + "?" + urlencode({"exp": expiry, "sig": signature(secret, path, expiry)})


def make_server(root, secret, port=0):
    root = Path(root).resolve()
    if len(secret) < 32:
        raise ValueError("use at least 32 random bytes")
    # Strict allowlist: no arbitrary path concatenation, no nested manifests.
    allowed = {"/media/index.m3u8": root / "index.m3u8"}
    manifest = (root / "index.m3u8").read_text()
    for line in manifest.splitlines():
        if line and not line.startswith("#"):
            if not re.fullmatch(r"seg[0-9]{3}\.ts", line):
                raise ValueError("unsupported manifest URI")
            file = root / line
            if file.is_symlink() or not file.is_file():
                raise ValueError("invalid segment")
            allowed["/media/" + line] = file
    if allowed["/media/index.m3u8"].is_symlink():
        raise ValueError("manifest symlink rejected")

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # Do not log signed query strings.

        def reject(self, status, total=None):
            self.send_response(status)
            self.send_header("Cache-Control", "private, no-store")
            if total is not None:
                self.send_header("Content-Range", f"bytes */{total}")
            self.send_header("Content-Length", "0")
            self.end_headers()

        def do_GET(self):
            parsed = urlsplit(self.path)
            if parsed.path not in allowed:
                return self.reject(404)
            query = parse_qs(parsed.query, keep_blank_values=True)
            if set(query) != {"exp", "sig"} or any(len(v) != 1 for v in query.values()):
                return self.reject(403)
            raw_exp, supplied = query["exp"][0], query["sig"][0]
            if not re.fullmatch(r"[0-9]{10}", raw_exp) or not re.fullmatch(r"[0-9a-f]{64}", supplied):
                return self.reject(403)
            expiry = int(raw_exp)
            now = int(time.time())
            if expiry <= now or expiry - now > 300:
                return self.reject(403)
            expected = signature(secret, parsed.path, expiry)
            if not hmac.compare_digest(expected, supplied):
                return self.reject(403)
            if parsed.path.endswith(".m3u8"):
                lines = [signed_url(secret, "/media/" + line, expiry)
                         if line and not line.startswith("#") else line
                         for line in manifest.splitlines()]
                body = ("\n".join(lines) + "\n").encode()
                content_type = "application/vnd.apple.mpegurl"
            else:
                body = allowed[parsed.path].read_bytes()
                content_type = "video/mp2t"
            total = len(body)
            content_range = None
            if "Range" in self.headers:
                match = re.fullmatch(r"bytes=([0-9]+)-([0-9]*)", self.headers["Range"])
                if not match:
                    return self.reject(416, total)
                start = int(match[1])
                end = min(int(match[2]), total - 1) if match[2] else total - 1
                if start >= total or end < start:
                    return self.reject(416, total)
                body = body[start:end + 1]
                content_range = f"bytes {start}-{end}/{total}"
            self.send_response(206 if content_range else 200)
            if content_range:
                self.send_header("Content-Range", content_range)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Type", content_type)
            self.send_header("Cache-Control", "private, no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    return ThreadingHTTPServer(("127.0.0.1", port), Handler)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("root")
    parser.add_argument("--port", type=int, default=8088)
    args = parser.parse_args()
    secret = bytes.fromhex(os.environ["HLS_DEMO_SECRET"])
    server = make_server(args.root, secret, args.port)
    print(f"Listening on 127.0.0.1:{server.server_port}", flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()
