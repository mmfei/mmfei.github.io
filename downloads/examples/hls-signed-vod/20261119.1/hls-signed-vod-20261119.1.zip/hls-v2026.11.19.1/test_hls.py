import json
import secrets
import subprocess
import sys
import threading
import time
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from auth_server import make_server, signed_url

root = Path(sys.argv[1])
secret = secrets.token_bytes(32)
server = make_server(root, secret)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
origin = f"http://127.0.0.1:{server.server_port}"
expiry = int(time.time()) + 120
checks = []

def check(name, ok):
    assert ok, name
    checks.append(name)

def get(path, headers=None):
    try:
        with urlopen(Request(origin + path, headers=headers or {}), timeout=5) as response:
            return response.status, response.read(), dict(response.headers)
    except HTTPError as e:
        return e.code, e.read(), dict(e.headers)

try:
    local = (root / "index.m3u8").read_text()
    durations = [float(line.split(":", 1)[1].rstrip(",")) for line in local.splitlines() if line.startswith("#EXTINF:")]
    check("three two-second video segments", len(durations) == 3 and all(abs(d-2) < 0.05 for d in durations))
    check("VOD end marker", "#EXT-X-ENDLIST" in local)
    for i in range(3):
        packets = json.loads(subprocess.check_output(["ffprobe", "-v", "error", "-select_streams", "v:0",
            "-read_intervals", "%+#1", "-show_packets", "-show_entries", "packet=flags", "-of", "json",
            str(root / f"seg{i:03d}.ts")]))["packets"]
        check("segment starts with video keyframe " + str(i), bool(packets) and "K" in packets[0]["flags"])
    check("local decode has no error", (root / "decode-errors.log").stat().st_size == 0)
    playlist = signed_url(secret, "/media/index.m3u8", expiry)
    status, body, headers = get(playlist)
    check("signed playlist allowed", status == 200)
    check("private no-store playlist", headers["Cache-Control"] == "private, no-store")
    segments = [s for s in body.decode().splitlines() if s and not s.startswith("#")]
    check("every segment URI carries own token", len(segments) == 3 and all("?exp=" in s and "&sig=" in s for s in segments))
    for i, segment in enumerate(segments):
        status, data, hdr = get(segment)
        check("signed segment " + str(i), status == 200 and len(data) > 0 and hdr["Content-Type"] == "video/mp2t")
    check("unsigned playlist denied", get("/media/index.m3u8")[0] == 403)
    check("unsigned segment denied", get("/media/seg000.ts")[0] == 403)
    check("expired signature denied", get(signed_url(secret, "/media/seg000.ts", int(time.time())-1))[0] == 403)
    check("wrong secret denied", get(signed_url(secrets.token_bytes(32), "/media/seg000.ts", expiry))[0] == 403)
    wrong_path = "/media/seg000.ts?" + playlist.split("?", 1)[1]
    check("playlist token cannot authorize segment", get(wrong_path)[0] == 403)
    check("duplicate query denied", get(playlist + "&exp=" + str(expiry))[0] == 403)
    check("unexpected path denied", get("/media/%2e%2e/secret")[0] == 404)
    r_status, r_data, r_headers = get(segments[0], {"Range": "bytes=0-10"})
    check("single byte range supported", r_status == 206 and len(r_data) == 11 and r_headers["Content-Range"].startswith("bytes 0-10/"))
    check("unsatisfiable range rejected", get(segments[0], {"Range": "bytes=9999999999-"})[0] == 416)
    check("overlong validity denied", get(signed_url(secret, "/media/index.m3u8", int(time.time())+600))[0] == 403)
    # Output is discarded; authenticated manifest and each segment fetched over local HTTP.
    run = subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-i", origin + playlist, "-f", "null", "-"],
                         capture_output=True, timeout=30)
    check("FFmpeg HTTP decode with segment auth", run.returncode == 0 and run.stderr == b"")
    print(json.dumps({"sandbox": str(root), "checks": checks, "count": len(checks),
         "durations": durations,
         "scope": "local TS VOD and localhost HMAC auth; no browser/CDN/DRM/order system validation"}, ensure_ascii=False, indent=2))
finally:
    server.shutdown()
    thread.join(timeout=5)
    server.server_close()
