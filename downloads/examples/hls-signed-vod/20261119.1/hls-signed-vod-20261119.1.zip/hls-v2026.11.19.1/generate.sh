#!/usr/bin/env bash
set -euo pipefail
work=$(mktemp -d "${TMPDIR:-/tmp}/hls-auth-demo.XXXXXX")
printf '%s\n' "$work"
cd "$work"
ffmpeg -hide_banner -nostdin -f lavfi -i "testsrc2=size=320x180:rate=25:duration=6" \
  -f lavfi -i "sine=frequency=440:sample_rate=48000:duration=6" \
  -map 0:v:0 -map 1:a:0 -c:v libx264 -preset veryfast -crf 23 -pix_fmt yuv420p \
  -g 50 -keyint_min 50 -sc_threshold 0 -flags +cgop \
  -c:a aac -b:a 96k -t 6 -f hls -hls_time 2 -hls_list_size 0 \
  -hls_playlist_type vod -hls_flags independent_segments \
  -hls_segment_filename 'seg%03d.ts' index.m3u8 2>encode.log
ffmpeg -hide_banner -nostdin -v error -i index.m3u8 -f null - 2>decode-errors.log
