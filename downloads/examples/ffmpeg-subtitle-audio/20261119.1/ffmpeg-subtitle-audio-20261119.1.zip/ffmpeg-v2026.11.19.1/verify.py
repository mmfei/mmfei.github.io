import json
import math
import struct
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])
probe = json.loads((root / "probe.json").read_text())
video = [s for s in probe["streams"] if s["codec_type"] == "video"]
audio = [s for s in probe["streams"] if s["codec_type"] == "audio"]
checks = []
def check(name, ok):
    assert ok, name
    checks.append(name)
check("one H264 video", len(video) == 1 and video[0]["codec_name"] == "h264")
check("yuv420p video", video[0]["pix_fmt"] == "yuv420p")
check("one AAC audio", len(audio) == 1 and audio[0]["codec_name"] == "aac")
check("48kHz audio", audio[0]["sample_rate"] == "48000")
check("six-second container within 0.1s", abs(float(probe["format"]["duration"]) - 6) < 0.1)
check("streams within 0.1s", all(abs(float(s["duration"]) - 6) < 0.1 for s in (video[0], audio[0])))
check("no decode errors", (root / "decode-errors.log").stat().st_size == 0)
log = (root / "encode.log").read_text()
check("libass selected CJK font", "NotoSansCJK" in log)
check("no missing glyph messages", "Glyph" not in log and "glyph" not in log)

def rms(start):
    data = subprocess.check_output(["ffmpeg", "-nostdin", "-v", "error", "-ss", str(start),
        "-i", str(root / "output.mp4"), "-t", "0.8", "-vn", "-ac", "1", "-ar", "48000",
        "-f", "f32le", "pipe:1"])
    values = struct.unpack("<" + "f" * (len(data) // 4), data)
    assert values
    return math.sqrt(sum(x*x for x in values) / len(values))
head = rms(0.5)
tail = rms(5)
check("synthetic audio exists before end", head > 0.01)
check("padded tail is near silence", tail < 0.0001)
print(json.dumps({"sandbox": str(root), "checks": checks, "count": len(checks),
    "head_rms": head, "tail_rms": tail,
    "scope": "synthetic video/audio; decode and stream assertions; still frame separate; no player or CDN test"},
    ensure_ascii=False, indent=2))
