#!/usr/bin/env bash
set -euo pipefail

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    printf '错误：找不到命令 %s。请先安装后再运行本脚本。\n' "$1" >&2
    exit 1
  fi
}

require_cmd ffmpeg
require_cmd ffprobe
require_cmd fc-match

target_family='Noto Sans CJK SC'
family_raw="$(fc-match -f '%{family}\n' "${target_family}:lang=zh-cn" || true)"
family="$(printf '%s\n' "$family_raw" | head -n 1 | cut -d, -f1)"
family="${family#"${family%%[![:space:]]*}"}"
family="${family%"${family##*[![:space:]]}"}"

if [[ -z "$family" || "$family" != "$target_family" ]]; then
  printf '错误：未匹配到目标字体 Noto Sans CJK SC。\n' >&2
  printf '错误：fc-match 返回：%s\n' "${family_raw:-（空）}" >&2
  printf '错误：fc-match 有返回值不等于目标字体已经存在，不能接受普通 Noto、Droid 或空结果。\n' >&2
  printf '错误：Debian/Ubuntu 可先安装：sudo apt-get update && sudo apt-get install fontconfig fonts-noto-cjk\n' >&2
  printf '错误：其他系统请按本机字体包和 fontconfig 的能力检查后再运行。\n' >&2
  exit 1
fi

work=$(mktemp -d "${TMPDIR:-/tmp}/ffmpeg-subtitle-demo.XXXXXX")
printf '%s\n' "$work"
cd "$work"
printf '%s\n' "$family" > font-family.txt
{
  printf 'confirmed_family=%s\n' "$family"
  printf 'fc-match_query=Noto Sans CJK SC:lang=zh-cn\n'
  fc-match "${target_family}:lang=zh-cn" || true
  ffmpeg -version
  ffprobe -version
} > versions.txt
ffmpeg -hide_banner -nostdin -f lavfi -i "testsrc2=size=320x568:rate=25:duration=6" \
  -an -c:v libx264 -preset veryfast -crf 23 -pix_fmt yuv420p video.mp4 2>source-video.log
ffmpeg -hide_banner -nostdin -f lavfi -i "sine=frequency=440:sample_rate=48000:duration=4" \
  -c:a pcm_s16le voice.wav 2>source-audio.log
cat > captions.srt <<'SRT'
1
00:00:00,500 --> 00:00:02,500
第一幕：测试字幕

2
00:00:03,000 --> 00:00:05,500
仅使用合成素材
SRT
ffmpeg -hide_banner -nostdin -i video.mp4 -i voice.wav \
  -map 0:v:0 -map 1:a:0 \
  -vf "subtitles=filename=captions.srt:force_style='FontName=Noto Sans CJK SC,FontSize=20,MarginV=24,Outline=1'" \
  -af "apad,atrim=duration=6,asetpts=PTS-STARTPTS" -t 6 \
  -c:v libx264 -preset veryfast -crf 23 -pix_fmt yuv420p \
  -c:a aac -b:a 128k -ar 48000 -movflags +faststart output.mp4 2>encode.log
ffprobe -v error -show_entries stream=index,codec_type,codec_name,pix_fmt,sample_rate,duration:format=duration \
  -of json output.mp4 > probe.json
ffmpeg -hide_banner -nostdin -v error -i output.mp4 -f null - 2>decode-errors.log
ffmpeg -hide_banner -nostdin -v error -ss 1 -i output.mp4 -frames:v 1 subtitle-frame.png
